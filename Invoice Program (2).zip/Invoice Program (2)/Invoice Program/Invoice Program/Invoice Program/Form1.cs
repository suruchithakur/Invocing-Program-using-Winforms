﻿using System.Data.SqlClient;
using System.Data;
namespace Invoice_Program
{
  
    public partial class Form1 : Form
    {
        string a;
        SqlConnection cnn;
        string connectionString = @"Data Source=localhost\SQLEXPRESS;Initial Catalog=db;User ID=sa;Password=sa";
        double rice = 1.79;
        double beans = 2.05;
        double butter = 1.73;
        double[] items = new double[5];
        SqlCommand cmd;
      
        public Form1()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            DialogResult iExit;
            iExit = MessageBox.Show("Confirm if you want to exit", "Invoice Generation System", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (iExit == DialogResult.Yes)
            {
                Application.Exit();
            }

            try
            {
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void printPreviewDialog1_Load(object sender, EventArgs e)
        {
            richTextBox1.AppendText(label2.Text + "\t" + "\t" + label3.Text + "\t" + "\t" + label4.Text + "\t" + "\t");
            richTextBox1.AppendText(label6.Text + "\t" + "\t" + numericUpDown1.Text + "\t" + "\t" + textBox1.Text + "\t" + "\t");
            richTextBox1.AppendText(label7.Text + "\t" + "\t" + numericUpDown2.Text + "\t" + "\t" + textBox2.Text + "\t" + "\t");
            richTextBox1.AppendText(label8.Text + "\t" + "\t" + numericUpDown3.Text + "\t" + "\t" + textBox3.Text + "\t" + "\t");

            richTextBox1.AppendText(label9.Text + "\t" + "\t" + textBox5.Text + "\t" + "\t" + textBox4.Text + "\t" + "\t");
            try
            {
                printPreviewDialog1.ShowDialog();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Invoice Generation System", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        private void printDocument1_PrintPage(object sender, System.Drawing.Printing.PrintPageEventArgs e)
        {
            try
            {
                System.Drawing.Font fntString = new System.Drawing.Font("Arial", 18, FontStyle.Regular);
                e.Graphics.DrawString(label4.Text, fntString, Brushes.Black, 120, 120);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Invoice Generation System", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

       

        private void numericUpDown1_ValueChanged(object sender, EventArgs e)
        {
            double i = Convert.ToDouble(numericUpDown1.Value);
            textBox1.Text = string.Format("{0:c2}", i * rice);
        }

        private void numericUpDown2_ValueChanged(object sender, EventArgs e)
        {
            double i = Convert.ToDouble(numericUpDown2.Value);
            textBox2.Text = string.Format("{0:c2}", i * beans);
        }

        private void numericUpDown3_ValueChanged(object sender, EventArgs e)
        {
            double i = Convert.ToDouble(numericUpDown3.Value);
            textBox3.Text = string.Format("{0:c2}", i * butter);
        }
        private void button2_Click(object sender, EventArgs e)
        {
            double[] q = new double[5];
            q[0] = Convert.ToDouble(numericUpDown1.Value);
            q[1] = Convert.ToDouble(numericUpDown2.Value);
            q[2] = Convert.ToDouble(numericUpDown3.Value);
            q[3] = q[0] + q[1] + q[2];

            textBox5.Text = Convert.ToString(q[3]);
            items [0] = q[0] * rice;
            items [1] = q[1] * beans;
            items [2] = q[2] * butter;
            items[3] = items[0] + items[1] + items[2];
            textBox4.Text = Convert.ToString(items[3]);

        }

        private void button1_Click(object sender, EventArgs e)
        {
            cnn = new SqlConnection(connectionString);

            a = "a";

                cnn.Open();
                MessageBox.Show("Connection Open  !");

                richTextBox1.AppendText(label2.Text + "\t" + "\t" + label3.Text + "\t" + "\t" + label4.Text + "\n" + "\n");
            richTextBox1.AppendText(label6.Text + "\t" + "\t" + numericUpDown1.Text + "\t" + "\t" + textBox1.Text + "\n" + "\n");
            richTextBox1.AppendText(label7.Text + "\t" + "\t" + numericUpDown2.Text + "\t" + "\t" + textBox2.Text + "\n" + "\n");
            richTextBox1.AppendText(label8.Text + "\t" + "\t" + numericUpDown3.Text + "\t" + "\t" + textBox3.Text + "\n" + "\n");

            richTextBox1.AppendText(label9.Text + "\t" + "\t" + textBox5.Text + "\t" + "\t" + textBox4.Text + "\n" + "\n");

            string query = "INSERT INTO Table_1 (rice,beans,butter,total) VALUES("+numericUpDown1.Text+ "," + numericUpDown2.Text + "," + numericUpDown3.Text + ",'"+textBox5.Text+"')";
            SqlCommand cmd = new SqlCommand(query, cnn);
                 
                cmd.ExecuteNonQuery();
                cnn.Close();


            }
    }
}